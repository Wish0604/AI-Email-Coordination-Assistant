export interface Thread {
  id: string;
  contact: string;
  avatar: string;
  subject: string;
  status: 'pending' | 'processing' | 'done';
  lastMessage: string;
  time: string;
  messages: Message[];
  detectedAvailability?: string[];
  proposedAction?: string;
}

export interface Message {
  id: string;
  sender: string;
  avatar: string;
  time: string;
  content: string;
  isAI?: boolean;
}

export interface Meeting {
  id: string;
  title: string;
  time: string;
  date: string;
  type: 'zoom' | 'in-person' | 'call';
  link?: string;
  status?: 'confirmed' | 'cancelled';
}

export interface Activity {
  id: string;
  type: 'negotiating' | 'scheduled' | 'drafted';
  contact: string;
  details: string;
  time: string;
  status: 'in-progress' | 'done' | 'drafting';
}

export interface Collaborator {
  id: string;
  name: string;
  role: string;
  avatar: string;
  priority: 'always-bypass' | 'high' | 'normal';
}
