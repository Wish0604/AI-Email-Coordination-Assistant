import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Mail, 
  Calendar, 
  Users, 
  Settings, 
  Search, 
  Bell, 
  Mic, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  Bot,
  AlertCircle,
  Video,
  X,
  MoreHorizontal,
  Archive,
  Star,
  Zap,
  BrainCircuit,
  History,
  Keyboard,
  Plus,
  Inbox,
  Filter,
  ArrowUpRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Thread, Meeting, Activity, Collaborator, Message } from './types';

// Mock Data
const MOCK_THREADS: Thread[] = [
  {
    id: '1',
    contact: 'Rahul Mehta',
    avatar: 'https://picsum.photos/seed/rahul/100/100',
    subject: 'Intro Call - Cloud Architecture',
    status: 'pending',
    lastMessage: 'The suggested Tuesday 2 PM slot works, but I\'m checking if Rahul is free for a follow-up call on Thursday instead.',
    time: '2m ago',
    detectedAvailability: ['Tue, 2:00 PM – 5:00 PM'],
    proposedAction: 'Suggest Tuesday at 3:00 PM. This works for everyone and respects your preference for "focused mornings."',
    messages: [
      {
        id: 'm1',
        sender: 'Rahul Mehta',
        avatar: 'https://picsum.photos/seed/rahul/100/100',
        time: '10:45 AM',
        content: 'Hey team, we need to finalize the roadmap by Friday. When is everyone free for a quick 30min sync? I\'m open most of Tuesday afternoon after 2 PM.'
      }
    ]
  },
  {
    id: '2',
    contact: 'Maria Garcia',
    avatar: 'https://picsum.photos/seed/maria/100/100',
    subject: 'Partnership Opportunity',
    status: 'processing',
    lastMessage: 'Analyzing proposal details...',
    time: '1h ago',
    messages: []
  }
];

const MOCK_MEETINGS: Meeting[] = [
  {
    id: '1',
    title: 'Internal Sync: AI Agents',
    time: '2:00 PM - 3:00 PM',
    date: '25 OCT',
    type: 'zoom',
    link: 'https://zoom.us/j/123456789'
  },
  {
    id: '2',
    title: 'Coffee with David',
    time: '4:30 PM - 5:00 PM',
    date: '25 OCT',
    type: 'in-person',
    status: 'cancelled'
  }
];

const MOCK_ACTIVITIES: Activity[] = [
  {
    id: '1',
    type: 'negotiating',
    contact: 'Rahul Mehta',
    details: 'The suggested Tuesday 2 PM slot works, but I\'m checking if Rahul is free for a follow-up call on Thursday instead.',
    time: '2 minutes ago',
    status: 'in-progress'
  },
  {
    id: '2',
    type: 'scheduled',
    contact: 'Sarah Chen',
    details: 'Calendar invite sent for \'Product Sync\' on Friday, Oct 27 at 10:00 AM.',
    time: '1 hour ago',
    status: 'done'
  }
];

const MOCK_COLLABORATORS: Collaborator[] = [
  { id: '1', name: 'Sarah Chen', role: 'Project Lead', avatar: 'https://picsum.photos/seed/sarah/100/100', priority: 'always-bypass' },
  { id: '2', name: 'Marcus Aurelius', role: 'CTO', avatar: 'https://picsum.photos/seed/marcus/100/100', priority: 'high' }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inbox' | 'calendar' | 'settings' | 'voice'>('dashboard');
  const [selectedThread, setSelectedThread] = useState<Thread | null>(null);
  const [isAutonomous, setIsAutonomous] = useState(true);

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Good morning, Alex</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">Your assistant has saved you 2.5 hours today.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-sky-500 text-white rounded-lg text-sm font-semibold hover:bg-sky-600 transition-colors shadow-sm">
            <Plus size={16} /> New Coordination
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Active Negotiations" value="12" icon={<Bot className="text-sky-500" />} />
        <StatCard title="Meetings Scheduled" value="8" icon={<Calendar className="text-sky-500" />} />
        <StatCard title="Time Saved" value="14.5h" icon={<Clock className="text-sky-500" />} />
        <StatCard title="Efficiency" value="98%" icon={<Zap className="text-sky-500" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active AI Actions */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Bot size={18} className="text-sky-500" /> Active Coordination
              </h3>
              <button className="text-xs text-sky-500 font-semibold hover:underline">View all</button>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {MOCK_ACTIVITIES.map(activity => (
                <div key={activity.id} className="p-4 flex items-start gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <div className={`size-10 rounded-full flex items-center justify-center shrink-0 
                    ${activity.status === 'done' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-sky-500/10 text-sky-500'}`}>
                    {activity.status === 'done' ? <CheckCircle2 size={20} /> : <Bot size={20} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)} with {activity.contact}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 italic">"{activity.details}"</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-[10px] text-slate-400 font-medium">{activity.time}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase 
                        ${activity.status === 'done' ? 'bg-emerald-500/10 text-emerald-500' : 
                          activity.status === 'in-progress' ? 'bg-amber-500/10 text-amber-500' : 'bg-sky-500/10 text-sky-500'}`}>
                        {activity.status}
                      </span>
                    </div>
                  </div>
                  <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400">
                    <ArrowUpRight size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Threads */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Inbox size={18} className="text-sky-500" /> Recent Threads
              </h3>
              <div className="flex gap-2">
                <button className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400"><Filter size={14} /></button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 text-[10px] uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-3 font-bold">Contact</th>
                    <th className="px-6 py-3 font-bold">Subject</th>
                    <th className="px-6 py-3 font-bold">AI Status</th>
                    <th className="px-6 py-3 font-bold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {MOCK_THREADS.map(thread => (
                    <tr key={thread.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group cursor-pointer" onClick={() => setSelectedThread(thread)}>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <img src={thread.avatar} alt={thread.contact} className="size-8 rounded-full" referrerPolicy="no-referrer" />
                          <span className="font-medium text-slate-900 dark:text-white">{thread.contact}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-500 dark:text-slate-400 max-w-[200px] truncate">{thread.subject}</td>
                      <td className="px-6 py-4">
                        <span className={`flex items-center gap-1.5 text-xs font-medium ${
                          thread.status === 'pending' ? 'text-amber-500' : 'text-sky-500'
                        }`}>
                          <span className={`size-1.5 rounded-full ${thread.status === 'pending' ? 'bg-amber-500' : 'bg-sky-500 animate-pulse'}`} />
                          {thread.status === 'pending' ? 'Awaiting' : 'Active'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button className="text-sky-500 hover:text-sky-600 font-bold text-xs">Review</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Sidebar Column */}
        <div className="space-y-6">
          {/* Calendar Preview */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar size={18} className="text-sky-500" /> Today's Schedule
              </h3>
            </div>
            <div className="p-4 space-y-4">
              {MOCK_MEETINGS.map(meeting => (
                <div key={meeting.id} className={`flex gap-3 ${meeting.status === 'cancelled' ? 'opacity-50' : ''}`}>
                  <div className={`flex flex-col items-center justify-center rounded-lg w-10 py-1 shrink-0 
                    ${meeting.status === 'cancelled' ? 'bg-slate-100 dark:bg-slate-800' : 'bg-sky-500/10'}`}>
                    <span className={`text-[8px] font-bold ${meeting.status === 'cancelled' ? 'text-slate-400' : 'text-sky-500'}`}>
                      {meeting.date.split(' ')[1]}
                    </span>
                    <span className={`text-sm font-black leading-none ${meeting.status === 'cancelled' ? 'text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                      {meeting.date.split(' ')[0]}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs font-bold truncate ${meeting.status === 'cancelled' ? 'line-through' : ''} text-slate-900 dark:text-white`}>
                      {meeting.title}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5">{meeting.time}</p>
                  </div>
                </div>
              ))}
              <button className="w-full py-2 text-[10px] font-bold text-slate-400 hover:text-sky-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg transition-colors">
                View Full Calendar
              </button>
            </div>
          </div>

          {/* AI Performance */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-800 dark:to-slate-950 rounded-xl p-5 text-white shadow-lg border border-white/5">
            <div className="flex justify-between items-start mb-4">
              <BrainCircuit size={20} className="text-sky-400" />
              <span className="bg-white/10 px-2 py-0.5 rounded text-[9px] font-bold uppercase">System Optimal</span>
            </div>
            <h4 className="text-sm font-bold mb-1">Autonomous Mode</h4>
            <p className="text-slate-400 text-[11px] mb-4">AI is currently handling 8 active negotiations without human intervention.</p>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-medium text-slate-400">Success Rate</span>
              <span className="text-[10px] font-bold text-sky-400">98.2%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-1 mb-4">
              <div className="bg-sky-400 h-full rounded-full w-[98%]" />
            </div>
            <button className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 rounded-lg text-[11px] transition-colors">
              Efficiency Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderThreadView = () => {
    if (!selectedThread) return null;
    return (
      <div className="flex flex-col lg:flex-row h-full bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="flex-1 flex flex-col min-w-0">
          <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <button onClick={() => setSelectedThread(null)} className="flex items-center gap-2 text-sm text-slate-500 hover:text-sky-500 transition-colors">
              <ChevronRight className="rotate-180 size-4" /> Back
            </button>
            <div className="flex gap-2">
              <button className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"><Archive size={16} /></button>
              <button className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"><MoreHorizontal size={16} /></button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <div className="mb-8">
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">{selectedThread.subject}</h1>
              <p className="text-xs text-slate-500 mt-1">Thread with {selectedThread.contact} • Started 2 days ago</p>
            </div>

            <div className="space-y-6">
              {selectedThread.messages.map(msg => (
                <div key={msg.id} className="flex gap-4">
                  <img src={msg.avatar} alt={msg.sender} className="size-9 rounded-full shrink-0" referrerPolicy="no-referrer" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between mb-1">
                      <h4 className="font-semibold text-sm text-slate-900 dark:text-white">{msg.sender}</h4>
                      <span className="text-[10px] text-slate-400">{msg.time}</span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl rounded-tl-none text-sm text-slate-700 dark:text-slate-300 leading-relaxed border border-slate-100 dark:border-slate-800">
                      {msg.content}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 border-t border-slate-100 dark:border-slate-800">
            <div className="flex gap-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
              <div className="size-8 rounded-full bg-sky-500/10 flex items-center justify-center shrink-0 text-sky-500">
                <Bot size={16} />
              </div>
              <textarea 
                className="flex-1 bg-transparent border-none text-sm focus:ring-0 outline-none resize-none py-1 dark:text-white" 
                placeholder="Draft a reply or let AI handle it..." 
                rows={2}
              />
              <button className="self-end px-4 py-1.5 bg-sky-500 text-white rounded-lg text-xs font-bold hover:bg-sky-600 transition-colors">
                Send
              </button>
            </div>
          </div>
        </div>

        <aside className="w-full lg:w-72 border-l border-slate-100 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-900/50 p-5 flex flex-col gap-6">
          <div>
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">AI Intelligence</h3>
            <div className="space-y-3">
              <div className="bg-white dark:bg-slate-800 rounded-xl p-3 border border-slate-200 dark:border-slate-700 shadow-sm">
                <p className="text-[10px] font-bold text-sky-500 mb-1">Detected Availability</p>
                {selectedThread.detectedAvailability?.map((avail, i) => (
                  <p key={i} className="text-xs font-semibold text-slate-900 dark:text-white">{avail}</p>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-sky-500 rounded-xl p-4 text-white shadow-lg relative overflow-hidden">
            <h4 className="text-xs font-bold flex items-center gap-2 mb-2">
              <Bot size={14} /> Proposed Action
            </h4>
            <p className="text-[11px] leading-relaxed mb-4 opacity-90">
              {selectedThread.proposedAction}
            </p>
            <button className="w-full bg-white text-sky-500 py-1.5 rounded-lg text-[10px] font-bold hover:bg-slate-100 transition-colors">
              Execute Suggestion
            </button>
          </div>

          <div className="mt-auto p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-900/30">
            <div className="flex gap-2">
              <AlertCircle className="text-amber-500 size-4 shrink-0" />
              <p className="text-[10px] text-amber-700 dark:text-amber-400 leading-tight">
                Conflict detected with "Weekly Standup" on Wednesday morning.
              </p>
            </div>
          </div>
        </aside>
      </div>
    );
  };

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <aside className="hidden md:flex flex-col w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
        <div className="p-6 flex items-center gap-3">
          <div className="size-8 bg-sky-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
            <Zap size={20} fill="currentColor" />
          </div>
          <span className="font-bold text-lg tracking-tight">MailSync AI</span>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <SidebarLink active={activeTab === 'dashboard'} onClick={() => {setActiveTab('dashboard'); setSelectedThread(null);}} icon={<LayoutDashboard size={18} />} label="Dashboard" />
          <SidebarLink active={activeTab === 'inbox'} onClick={() => setActiveTab('inbox')} icon={<Inbox size={18} />} label="Inbox" badge="12" />
          <SidebarLink active={activeTab === 'calendar'} onClick={() => setActiveTab('calendar')} icon={<Calendar size={18} />} label="Calendar" />
          <SidebarLink active={activeTab === 'voice'} onClick={() => setActiveTab('voice')} icon={<Mic size={18} />} label="Voice Assistant" />
          <div className="h-px bg-slate-100 dark:bg-slate-800 my-4 mx-2" />
          <SidebarLink active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} icon={<Settings size={18} />} label="Settings" />
        </nav>

        <div className="p-4">
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Autonomous</span>
              <button 
                onClick={() => setIsAutonomous(!isAutonomous)}
                className={`relative w-8 h-4 rounded-full transition-colors ${isAutonomous ? 'bg-sky-500' : 'bg-slate-300 dark:bg-slate-600'}`}
              >
                <div className={`absolute top-0.5 left-0.5 size-3 bg-white rounded-full transition-transform ${isAutonomous ? 'translate-x-4' : ''}`} />
              </button>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed">AI is currently managing your schedule automatically.</p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between px-6 shrink-0">
          <div className="flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 size-4" />
            <input 
              type="text" 
              placeholder="Search anything..." 
              className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-lg pl-10 pr-4 py-1.5 text-sm focus:ring-1 focus:ring-sky-500 outline-none"
            />
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-400 hover:text-sky-500 transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 size-1.5 bg-red-500 rounded-full border border-white dark:border-slate-900" />
            </button>
            <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 mx-1" />
            <div className="flex items-center gap-3 pl-2">
              <img src="https://picsum.photos/seed/alex/100/100" alt="Profile" className="size-8 rounded-full border border-slate-200 dark:border-slate-700" referrerPolicy="no-referrer" />
              <div className="hidden sm:block">
                <p className="text-xs font-bold leading-none">Alex Rivera</p>
                <p className="text-[9px] text-sky-500 font-bold mt-1">PRO</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedThread ? 'thread' : activeTab}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              {selectedThread ? renderThreadView() : (
                <>
                  {activeTab === 'dashboard' && renderDashboard()}
                  {activeTab === 'inbox' && (
                    <div className="space-y-6">
                      <h1 className="text-2xl font-bold">Inbox</h1>
                      <PriorityThreads threads={MOCK_THREADS} onSelect={setSelectedThread} />
                    </div>
                  )}
                  {activeTab === 'calendar' && <CalendarView />}
                  {activeTab === 'settings' && (
                    <div className="space-y-6">
                      <h1 className="text-2xl font-bold">Settings</h1>
                      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-500">
                        Settings configuration coming soon...
                      </div>
                    </div>
                  )}
                  {activeTab === 'voice' && <VoiceAssistantView />}
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

function CalendarView() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const daysInMonth = 31; // Simplified for MVP
  const startDay = 2; // Tuesday
  
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const padding = Array.from({ length: startDay }, (_, i) => null);
  const calendarGrid = [...padding, ...days];

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">October 2025</h1>
          <p className="text-sm text-slate-500">You have 8 meetings scheduled this month.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-sm font-semibold hover:bg-slate-50 transition-colors">Today</button>
          <div className="flex border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
            <button className="p-2 bg-white dark:bg-slate-900 hover:bg-slate-50 border-r border-slate-200 dark:border-slate-800"><ChevronRight className="rotate-180 size-4" /></button>
            <button className="p-2 bg-white dark:bg-slate-900 hover:bg-slate-50"><ChevronRight className="size-4" /></button>
          </div>
          <button className="px-4 py-2 bg-sky-500 text-white rounded-lg text-sm font-semibold hover:bg-sky-600 transition-colors shadow-sm flex items-center gap-2">
            <Plus size={16} /> Add Event
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-0">
        {/* Calendar Grid */}
        <div className="lg:col-span-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
          <div className="grid grid-cols-7 border-b border-slate-100 dark:border-slate-800">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="py-3 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                {day}
              </div>
            ))}
          </div>
          <div className="flex-1 grid grid-cols-7 grid-rows-5">
            {calendarGrid.map((day, i) => (
              <div 
                key={i} 
                className={`min-h-[100px] p-2 border-r border-b border-slate-50 dark:border-slate-800/50 last:border-r-0 
                  ${day === null ? 'bg-slate-50/30 dark:bg-slate-800/20' : 'hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors cursor-pointer'}
                  ${day === 25 ? 'bg-sky-500/5 dark:bg-sky-500/10' : ''}`}
              >
                {day && (
                  <>
                    <div className="flex justify-between items-start">
                      <span className={`text-xs font-bold ${day === 25 ? 'size-6 rounded-full bg-sky-500 text-white flex items-center justify-center' : 'text-slate-500'}`}>
                        {day}
                      </span>
                      {day === 25 && <div className="size-1.5 rounded-full bg-sky-500" />}
                    </div >
                    <div className="mt-2 space-y-1">
                      {day === 25 && MOCK_MEETINGS.map(m => (
                        <div key={m.id} className={`text-[9px] p-1 rounded truncate font-bold ${m.status === 'cancelled' ? 'bg-slate-100 text-slate-400 line-through' : 'bg-sky-100 dark:bg-sky-900/40 text-sky-600 dark:text-sky-400'}`}>
                          {m.title}
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Side Panel: Day Details */}
        <div className="space-y-6 overflow-y-auto pr-2">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
            <h3 className="font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <Calendar size={18} className="text-sky-500" /> Saturday, Oct 25
            </h3>
            <div className="space-y-4">
              {MOCK_MEETINGS.map(meeting => (
                <div key={meeting.id} className="relative pl-4 border-l-2 border-sky-500">
                  <div className="flex justify-between items-start">
                    <p className={`text-sm font-bold ${meeting.status === 'cancelled' ? 'text-slate-400 line-through' : 'text-slate-900 dark:text-white'}`}>
                      {meeting.title}
                    </p>
                    <button className="text-slate-400 hover:text-sky-500"><MoreHorizontal size={14} /></button>
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                    <Clock size={10} /> {meeting.time}
                  </p>
                  {meeting.type === 'zoom' && (
                    <a href={meeting.link} className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 bg-sky-500 text-white rounded-lg text-[10px] font-bold hover:bg-sky-600 transition-colors">
                      <Video size={12} /> Join Meeting
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 dark:bg-slate-800 rounded-xl p-5 text-white shadow-lg">
            <div className="flex items-center gap-2 mb-3">
              <Bot size={18} className="text-sky-400" />
              <h4 className="text-xs font-bold">AI Coordination</h4>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed mb-4">
              AI is negotiating 3 more slots for next week based on your "Focused Work" preferences.
            </p>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[9px] p-2 bg-white/5 rounded-lg border border-white/5">
                <span className="text-slate-300">Design Review</span>
                <span className="text-amber-400 font-bold">Negotiating</span>
              </div>
              <div className="flex items-center justify-between text-[9px] p-2 bg-white/5 rounded-lg border border-white/5">
                <span className="text-slate-300">Investor Sync</span>
                <span className="text-sky-400 font-bold">Proposed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function VoiceAssistantView() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] max-w-4xl mx-auto w-full py-12">
      {/* Listening State & Waveform */}
      <div className="w-full flex flex-col items-center mb-12">
        <div className="mb-8">
          <span className="inline-flex items-center gap-2 rounded-full bg-sky-500/10 px-4 py-1.5 text-sm font-semibold text-sky-500">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-sky-500 opacity-75 animate-ping"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
            </span>
            Listening...
          </span>
        </div>

        {/* Voice Wave Visualizer */}
        <div className="flex items-center justify-center gap-1.5 h-16 mb-10">
          {[0.4, 0.7, 1, 0.8, 0.5, 1, 0.7, 0.8, 0.4].map((opacity, i) => (
            <motion.div
              key={i}
              className="w-1.5 bg-sky-500 rounded-full"
              initial={{ height: 20 }}
              animate={{ height: [20, 40 + Math.random() * 20, 20] }}
              transition={{ 
                repeat: Infinity, 
                duration: 0.5 + Math.random() * 0.5,
                ease: "easeInOut"
              }}
              style={{ opacity }}
            />
          ))}
        </div>

        {/* Transcription Area */}
        <div className="w-full max-w-2xl text-center">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-slate-900 dark:text-white leading-tight mb-4">
            "Schedule a meeting with Rahul tomorrow at 3 PM"
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-lg">
            Processing your request...
          </p>
        </div>
      </div>

      {/* Feedback UI Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 mb-12 shadow-xl"
      >
        <div className="flex items-start gap-4">
          <div className="h-10 w-10 rounded-full bg-sky-500/10 flex items-center justify-center text-sky-500 shrink-0">
            <Calendar size={20} />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-slate-900 dark:text-white">New Calendar Event</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Meeting with Rahul</p>
            <div className="flex flex-wrap gap-2">
              <div className="flex items-center gap-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 px-3 py-1.5 text-xs font-medium">
                <Calendar size={14} className="text-slate-400" />
                Tomorrow
              </div>
              <div className="flex items-center gap-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 px-3 py-1.5 text-xs font-medium">
                <Clock size={14} className="text-slate-400" />
                3:00 PM - 4:00 PM
              </div>
            </div>
          </div>
          <button className="text-sky-500 font-bold text-sm hover:underline">Edit</button>
        </div>
      </motion.div>

      {/* Quick Actions Grid */}
      <div className="w-full max-w-2xl">
        <h4 className="text-center text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 mb-6">Quick Actions</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <VoiceAction icon={<Mail size={20} />} label="Send Email" />
          <VoiceAction icon={<CheckCircle2 size={20} />} label="Reminders" />
          <VoiceAction icon={<Zap size={20} />} label="Smart Home" />
          <VoiceAction icon={<Video size={20} />} label="Start Meeting" />
        </div>
      </div>

      {/* Bottom Controls Overlay */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 p-2 rounded-full bg-slate-900 dark:bg-slate-800 border border-white/10 shadow-2xl">
        <button className="p-3 rounded-full hover:bg-white/10 text-white transition-colors">
          <Keyboard size={20} />
        </button>
        <button className="p-4 rounded-full bg-sky-500 text-white shadow-lg shadow-sky-500/40 hover:bg-sky-600 transition-colors">
          <Mic size={28} />
        </button>
        <button className="p-3 rounded-full hover:bg-white/10 text-white transition-colors">
          <X size={20} />
        </button>
      </div>
    </div>
  );
}

function VoiceAction({ icon, label }: { icon: React.ReactNode, label: string }) {
  return (
    <button className="group flex flex-col items-center justify-center gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-sky-500/30 transition-all shadow-sm">
      <div className="h-12 w-12 rounded-xl bg-sky-500/10 flex items-center justify-center text-sky-500 group-hover:bg-sky-500 group-hover:text-white transition-all">
        {icon}
      </div>
      <span className="text-xs font-semibold">{label}</span>
    </button>
  )
}

function PriorityThreads({ threads, onSelect }: { threads: Thread[], onSelect: (t: Thread) => void }) {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
      <div className="divide-y divide-slate-100 dark:divide-slate-800">
        {threads.map(thread => (
          <div 
            key={thread.id} 
            onClick={() => onSelect(thread)}
            className="p-4 flex items-start gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer group"
          >
            <img src={thread.avatar} alt={thread.contact} className="size-10 rounded-full shrink-0" referrerPolicy="no-referrer" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">{thread.contact}</h4>
                <span className="text-[10px] text-slate-400">{thread.time}</span>
              </div>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate mb-1">{thread.subject}</p>
              <p className="text-xs text-slate-500 line-clamp-1 italic">"{thread.lastMessage}"</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <Star size={14} className="text-slate-300 group-hover:text-amber-400 transition-colors" />
              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                thread.status === 'pending' ? 'bg-amber-500/10 text-amber-500' : 'bg-sky-500/10 text-sky-500'
              }`}>
                {thread.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SidebarLink({ active, icon, label, onClick, badge }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void, badge?: string }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200
        ${active ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'}`}
    >
      <span className={active ? 'text-white' : 'text-slate-400'}>{icon}</span>
      <span className="text-sm font-semibold">{label}</span>
      {badge && (
        <span className={`ml-auto text-[10px] px-1.5 py-0.5 rounded-full font-bold 
          ${active ? 'bg-white/20 text-white' : 'bg-sky-500/10 text-sky-500'}`}>
          {badge}
        </span>
      )}
    </button>
  );
}

function StatCard({ title, value, icon }: { title: string, value: string, icon: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <span className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider">{title}</span>
        <div className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg">{icon}</div>
      </div>
      <div className="text-2xl font-bold text-slate-900 dark:text-white">{value}</div>
    </div>
  );
}
